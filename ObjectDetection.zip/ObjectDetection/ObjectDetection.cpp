#include "Arduino.h"
#include "Drive.h"		

int trigPin;
int echoPin;
float deltaD;
float dt;
int motion1;
int motion2;
int state_current = 0;
float distance;

ObjectDetection::ObjectDetection(int trigPin, int echoPin, int motion1, int motion2) {
	this->trigPin = trigPin;
	this->echoPin = echoPin;
	this->motion1 = motion1;
	this->motion2 = motion2;
	set_distance_sensor();
}

void ObjectDetection::inRange() {
	/*
		Maybe we can do something with this
	*/
	}

int ObjectDetection::updateObjDetection() {
	update_distance();
	return state_current;
	}
	
void ObjectDetection::set_distance_sensor() {
	pinMode(trigPin, OUTPUT);
	pinMode(echoPin, INPUT);
}
void ObjectDetection::update_distance() {
	// To start, send a low signal to the Sensor
	digitalWrite(trigPin, LOW);
	delayMicroseconds(2);
	// Then we want to send power to the sensor for ten microseconds, causing a sound wave to generate
	digitalWrite(trigPin, HIGH);
	delayMicroseconds(10);
	// Then, we want to change the signal back to low on the sensor
	digitalWrite(trigPin, LOW);
	// the Pulse in from the echoPin will give us the length in time it took for the signal to bounce back to the Sensor
	long duration = pulseIn(echoPin, HIGH);
	distance = (duration / 2) * 0.0343;
}

float ObjectDetection::distance() { return this->distance; }

bool left() {
	Serial.println(digitalRead(motion2);
	return true;
}
bool right() {
	//Serial.println(digitalRead(motion2);
	return true;
}
