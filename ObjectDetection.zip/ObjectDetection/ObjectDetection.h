#ifndef OBJECTDETECTION_Hl
#define OBJECTDETECTION_H

class ObjectDetection {
private:

	// VARIABLES
	
	int trigPin;
	int echoPin;
	float deltaD;
	float dt;
	float distance;
	int motion1;
	int motion2;
	int state_current;

	// METHODS

	void update_distance();
	void set_distance_sensor();

	bool left();
	bool right();

public:
	ObjectDetection(int trig, int echo, int ir1, int ir2); // Needs servo update
	void inRange();
	int updateObjDetection();
	float distance();

};

#endif
