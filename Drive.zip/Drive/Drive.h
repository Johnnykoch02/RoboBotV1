#ifndef Drive_h
#define Drive_H

// #include <Arduino.h>

class Drive {
  private:
    int in1;
    int in2;
    int enA;
    int in3;
    int in4;
    int enB;
    int encoder; 
    float rps;
    int rots; 
    int lastEncoderValue;
    
    float drive_matrix[3][3];

    float toRadians(float theta);
    void foward();
    void turnRight();
    void backward();
    void turnLeft();
    void stop();

    // We can have Vy and Vx in any form we want, even rotations per second.
  public:
    Drive(int in1,int in2,int enA,int in3,int in4,int enB,int encoder);
    float speed();
    void updateDrive(float dt);

    void set_drive_motors();

    bool change_in_encoder();

    void setDrive(float pctpower,int dir, float theta);

};
#endif